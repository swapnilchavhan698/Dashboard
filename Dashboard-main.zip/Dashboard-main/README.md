# Dashboard

Task: Design a Dashboard for Dreadnought Web App

![Dashboard](https://github.com/AnshChoudhary/Dashboard/blob/main/Screenshot%20(218).png)

## Instructions
Run the index.html file (preferably on Chrome/Edge).
